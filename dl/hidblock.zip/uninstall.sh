#! /bin/sh
rm "$HOME/.bin/hidblock"